import React from "react";
import LandingPage from "./pages/landing/index";

function App() {
  return <LandingPage />;
}

export default App;