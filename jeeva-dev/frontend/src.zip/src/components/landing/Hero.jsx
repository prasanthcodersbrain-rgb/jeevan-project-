import React from "react";
import HeroSlideOne from "./HeroSlideOne";
import HeroSlideTwo from "./HeroSlideTwo";
import HeroSlideThree from "./HeroSlideThree";

export default function Hero() {
  return (
    <div className="hero">
      <div className="hero__timeline" style={{ opacity: 0, translate: "none", rotate: "none", scale: "none", transform: "translate3d(0px, 0px, 0px)" }}></div>
      <div className="hero__track">
        <HeroSlideOne />
        <HeroSlideTwo />
        <HeroSlideThree />
      </div>
    </div>
  );
}
