import React from "react";
import Header from "../../components/landing/Header";
import Hero from "../../components/landing/Hero";
import Features from "../../components/landing/Features";
import HowItWorks from "../../components/landing/HowItWorks";
import Waitlist from "../../components/landing/Waitlist";
import Footer from "../../components/landing/Footer";
import WaitlistForm from "../../components/landing/WaitlistForm";

const CODE_STYLES_MARKUP = `<div class="code"><div class="w-embed"><style>
 	:root {
  	/* 1rem equals 10px at 375px of view width */
    font-size: clamp(62.5%, calc(100vw / 37.5), 100%);
    
    --global-transition-duration: 240ms;
    --global-transition-easing-function: ease-in-out;
  }
  
  @media screen and (width >= 768px) {
  	:root {
	    /* 1rem equals 10px at 1440px of view width */
      font-size: max(62.5%, calc(100vw / 144));
    }
  }
  
  *,
  *::before,
  *::after {
    box-sizing: border-box;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
  }
  
  body:has([data-scroll-locking-element="true"]) {
  	overflow: clip;
  }
  
  html {
  	overscroll-behavior: none;
  }
  
  .w-embed::before,
  .w-embed::after {
  	content: unset;
  }
</style></div><div class="w-embed w-script"></div><div class="w-embed"><style>
	body[data-page-scrolled-down="true"] .header {
  	opacity: 0;
    visibility: hidden;
  }
  
  body[data-page-scrolled-down="false"]:has(main > .hero:first-child) .header__home-link {
  	color: var(--_color---text);
  }
</style></div><div class="w-embed"><style>
	@media screen and (max-aspect-ratio: 40 / 29) {
    .hero-scene-2__avatar-bubble {
      visibility: hidden;
      pointer-events: none;
    }
  }
</style></div><div class="w-embed"><style>
	.rich-text > .rich-text__content > .rich-text__rich-text > *:first-child {
  	margin-top: unset;
  }
</style></div><div class="w-embed w-script"></div><div class="w-embed"><style>
  body:has(.waitlist-form--active) {
  	overflow: clip;
  }
</style></div></div>`;

export default function LandingPage() {
  return (
    <>
      <div dangerouslySetInnerHTML={{ __html: CODE_STYLES_MARKUP }} />
      <Header />
      <main className="main">
        <Hero />
        <Features />
        <HowItWorks />
        <Waitlist />
      </main>
      <Footer />
      <WaitlistForm />
    </>
  );
}
